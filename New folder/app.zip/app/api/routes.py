from fastapi import APIRouter, Depends
from app.services.models.agent import get_model, QAModel
from app.models.payload import QARequest
from app.models.prediction import QAResponse
from app.models.payload import QARequest, KnowledgeBaseItem
from app.models.payload import AddToKBRequest
from app.models.payload import BulkQARequest
router = APIRouter()
@router.post("/qna", response_model=QAResponse, name="qna")
def post_qna(
        request_payload: QARequest,
        model: QAModel = Depends(get_model)
) -> QAResponse:
    prediction_result = model.predict(request_payload.query)
    return QAResponse(**prediction_result)

@router.post("/kb/add", status_code=201, name="kb:add")
def add_knowledge_base_item(
    # ورودی باید با مدل جدید ما مطابقت داشته باشد
    request_payload: AddToKBRequest,
    model: QAModel = Depends(get_model)
):
    """
    یک جفت پرسش و پاسخ جدید را دریافت، امبد کرده و به پایگاه دانش اضافه می‌کند.
    """
    result = model.add_to_knowledge_base(
        new_question=request_payload.question,
        new_answer=request_payload.answer,
        tags=request_payload.tags
    )
    return result


@router.post("/bulk-add-qa", name="bulk_add_qa", status_code=202)  # 202 Accepted
def post_bulk_qna(
        request_payload: BulkQARequest,
        model: QAModel = Depends(get_model)
):
    """
    اندپوینتی برای دریافت لیستی (batch) از پرسش و پاسخ‌ها.
    این اندپوینت داده‌ها را برای پردازش بعدی دریافت کرده و فوراً پاسخ می‌دهد.
    """

    # فراخوانی تابع نمایشی (placeholder) در سرویس
    result = model.process_and_embed_bulk(request_payload)

    return result