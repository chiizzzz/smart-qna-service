from pydantic import BaseModel
from typing import List, Optional
from typing import List
class QARequest(BaseModel):
    query: str
class KnowledgeBaseItem(BaseModel):
    question: str
    answer: str
class AddToKBRequest(BaseModel):
    question: str
    answer: str
    tags: Optional[List[str]] = []
class SingleQAItem(BaseModel):
    question: str
    answer: str
class BulkQARequest(BaseModel):
    qa_list: List[SingleQAItem]