# مسیر فایل: app/services/models.py

# --- وارد کردن کتابخانه‌های لازم ---
import json
import numpy as np
import logging
import requests
import threading
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from app.core.config import settings
from app.models.payload import BulkQARequest

# --- وارد کردن کتابخانه Langfuse (فقط کلاس اصلی) ---
from langfuse import Langfuse  # <-- Langfuse: فقط کلاس اصلی را import می‌کنیم
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class QAModel:
    def __init__(self):
        self._knowledge_base = None
        self._all_doc_vectors = None
        self._embedder = None
        self.langfuse = None
        self._file_lock = threading.Lock()
        self._load_dependencies()

    def _load_dependencies(self):
        # ... بارگذاری مدل‌ها مثل قبل ...
        self._embedder = SentenceTransformer(settings.EMBEDDING_MODEL)
        with open(settings.VECTOR_STORE_PATH, "r", encoding="utf-8") as f:
            self._knowledge_base = json.load(f)
        self._all_doc_vectors = np.array([item["embedding"] for item in self._knowledge_base])

        # ... ساخت نمونه اصلی Langfuse بدون تغییر ...
        self.langfuse = Langfuse(
            public_key=settings.LANGFUSE_PUBLIC_KEY,
            secret_key=settings.LANGFUSE_SECRET_KEY,
        )
        print("Service: تمام مدل‌ها و اتصال Langfuse با موفقیت برقرار شد.")

    def _generate_tags(self, trace, user_query: str) -> list:
        # <-- Langfuse: استفاده از روش جدید برای ایجاد Generation
        generation = trace.generation(
            name="tag-generation",
            model=settings.LLM_MODEL,
            input={"query": user_query},
            prompt=[
                {"role": "system", "content": f"""شما یک سیستم طبقه‌بندی دقیق هستید..."""},
                {"role": "user", "content": f"سوال: \"{user_query}\""}
            ]
        )

        # بقیه کد این تابع بدون تغییر باقی می‌ماند
        url = "https://api.together.xyz/v1/chat/completions"
        headers = {"Authorization": f"Bearer {settings.TOGETHER_API_KEY}"}
        payload = {
            "model": settings.LLM_MODEL,
            "messages": [
                {"role": "system", "content": f"""..."""},
                {"role": "user", "content": f"سوال: \"{user_query}\""}
            ], "temperature": 0.0, "max_tokens": 100, "response_format": {"type": "json_object"}
        }
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=20)
            response.raise_for_status()
            tags = json.loads(response.json()["choices"][0]["message"]["content"])
            result = tags if isinstance(tags, list) else []
            generation.end(output={"tags": result})
            return result
        except Exception as e:
            print(f"[خطای تگ‌گذاری]: {e}")
            generation.end(level="ERROR", status_message=str(e))
            return []

    def _generate_response(self, trace, user_query: str, context_docs: list) -> str:
        # <-- Langfuse: استفاده از روش جدید برای ایجاد Generation
        generation = trace.generation(
            name="final-response-generation",
            model=settings.LLM_MODEL,
            input={"query": user_query, "context": context_docs}
        )

        # بقیه کد این تابع بدون تغییر باقی می‌ماند
        if not context_docs:
            self._send_to_operator(user_query)
            response_text = "متاسفانه پاسخ مشخصی برای سوال شما در پایگاه دانش ما وجود ندارد..."
            generation.end(output=response_text, level="WARNING", status_message="No context found")
            return response_text

        context_text = "\n\n---\n\n".join(
            [f"سوال: {item['question']}\nپاسخ: {item['answer']}" for item in context_docs])
        url = "https://api.together.xyz/v1/chat/completions"
        headers = {"Authorization": f"Bearer {settings.TOGETHER_API_KEY}"}
        payload = {
            "model": settings.LLM_MODEL,
            "messages": [
                {"role": "system", "content": "..."},
                {"role": "user", "content": f"## اطلاعات مرتبط:\n{context_text}\n\n## سوال کاربر:\n\"{user_query}\""}
            ], "temperature": 0.2, "max_tokens": 1000
        }
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=40)
            response.raise_for_status()
            final_answer = response.json()["choices"][0]["message"]["content"].strip()
            generation.end(output={"answer": final_answer})
            return final_answer
        except Exception as e:
            print(f"[خطا در تولید پاسخ]: {e}")
            generation.end(level="ERROR", status_message=str(e))
            return "متاسفانه در ارتباط با مدل هوش مصنوعی مشکلی پیش آمده است."

    def predict(self, user_query: str) -> dict:
        # <-- Langfuse: استفاده از روش جدید برای ایجاد Trace
        trace = self.langfuse.trace(
            name="qna-pipeline",
            input={"user_query": user_query},
        )

        # ۱. تگ‌گذاری
        tags = self._generate_tags(trace, user_query)

        # <-- Langfuse: استفاده از روش جدید برای ایجاد Span
        span = trace.span(
            name="vector-retrieval",
            input={"query": user_query}
        )

        # بقیه کد این بخش بدون تغییر است
        user_vector = self._embedder.encode(user_query)
        similarities = cosine_similarity([user_vector], self._all_doc_vectors)[0]
        matches = sorted([(self._knowledge_base[i], sim) for i, sim in enumerate(similarities) if
                          sim >= settings.SIMILARITY_THRESHOLD], key=lambda x: x[1], reverse=True)
        top_matches = [m[0] for m in matches[:3]]

        span.end(output={"retrieved_item_count": len(top_matches), "top_matches_ids": [m['id'] for m in top_matches]})

        # ۳. تولید پاسخ نهایی
        answer = self._generate_response(trace, user_query, top_matches)

        trace.update(output={"final_answer": answer, "identified_tags": tags})

        return {
            "tags_identified": tags,
            "final_answer": answer,
            "retrieved_context_count": len(top_matches)
        }

    # ... بقیه متدهای شما بدون تغییر باقی می‌مانند ...
    def add_to_knowledge_base(self, new_question: str, new_answer: str, tags: list):
        # ... کد کامل این متد ...
        print(f"Service: در حال افزودن آیتم جدید به پایگاه دانش: '{new_question}'")
        text_to_embed = f"سوال: {new_question}\n\nپاسخ: {new_answer}"
        embedding = self._embedder.encode(text_to_embed).tolist()
        new_item = {
            "id": f"qna-{len(self._knowledge_base)}",
            "question": new_question,
            "answer": new_answer,
            "tags": tags,
            "embedding": embedding
        }
        self._knowledge_base.append(new_item)
        self._all_doc_vectors = np.vstack([self._all_doc_vectors, np.array(embedding)])
        try:
            with open(settings.VECTOR_STORE_PATH, "w", encoding="utf-8") as f:
                json.dump(self._knowledge_base, f, ensure_ascii=False, indent=2)
            print("Service: پایگاه دانش با موفقیت به‌روزرسانی شد.")
            return {"status": "success", "item_id": new_item["id"]}
        except Exception as e:
            print(f"[خطا در ذخیره‌سازی پایگاه دانش]: {e}")
            return {"status": "failed", "error": str(e)}

    def _send_to_operator(self, unresolved_query: str):
        # ... کد کامل این متد ...
        print("-" * 30)
        print(f"INFO: سوال زیر به پنل اپراتور ارسال شد (شبیه‌سازی شده):")
        print(f"'{unresolved_query}'")
        print("-" * 30)
        pass

    def process_and_embed_bulk(self, payload: BulkQARequest) -> dict:
        # ... کد کامل این متد ...
        num_items = len(payload.qa_list)
        print(f"Service: دریافت درخواست برای پردازش دسته‌ای {num_items} آیتم.")
        return {
            "status": "success",
            "message": f"{num_items} پرسش و پاسخ با موفقیت دریافت شد و در صف پردازش قرار گرفت.",
            "items_received": num_items
        }

    def add_knowledge_item(self, item: dict) -> dict:
        # ... کد کامل این متد ...
        question = item['question']
        answer = item['answer']
        text_to_embed = f"سوال: {question}\n\nپاسخ: {answer}"
        embedding = self._embedder.encode(text_to_embed).tolist()

        # برای سادگی، تگ‌گذاری این بخش را به صورت یک trace جداگانه اجرا می‌کنیم
        tag_trace = self.langfuse.trace(name="ad-hoc-tagging-on-add")
        tags = self._generate_tags(tag_trace, question)

        new_id = len(self._knowledge_base)
        new_item = {
            "id": f"qna-{new_id}",
            "question": question,
            "answer": answer,
            "tags": tags,
            "embedding": embedding
        }
        with self._file_lock:
            self._knowledge_base.append(new_item)
            new_vector = np.array(embedding).reshape(1, -1)
            self._all_doc_vectors = np.vstack([self._all_doc_vectors, new_vector])
            with open(settings.VECTOR_STORE_PATH, "w", encoding="utf-8") as f:
                json.dump(self._knowledge_base, f, ensure_ascii=False, indent=2)
        return {"id": new_item["id"], "status": "Successfully added"}


# --- این دو خط بدون تغییر باقی می‌مانند ---
model_instance = QAModel()


def get_model():
    return model_instance